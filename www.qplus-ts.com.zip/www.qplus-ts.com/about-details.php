<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Services Details</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <meta property="og:image" content="assets/img/qplus_logo.png">
  <!-- Favicons -->
  <link href="assets/img/qplus_logo.png" rel="icon">
  <link href="assets/img/qplus_logo.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap"
    rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

</head>

<body class="services-details-page" data-bs-spy="scroll" data-bs-target="#navmenu">

  <body class="index-page" data-bs-spy="scroll" data-bs-target="#navmenu">
    <!-- ======= Header ======= -->
    <header id="header" class="header fixed-top d-flex align-items-center">
      <div class="container-fluid d-flex align-items-center justify-content-between">

        <a href="index.php" class="logo d-flex align-items-center me-auto me-xl-0">
          <!-- Uncomment the line below if you also wish to use an image logo -->
          <img src="assets/img/logo.png" alt="">
          <!-- <h1>Q PLUS</h1>
          <span>.</span> -->
        </a>

        <!-- Nav Menu -->
        <nav id="navmenu" class="navmenu">
          <ul>
            <li><a href="index.php#home">Home</a></li>
            <li><a href="index.php#about" class="active">About</a></li>
            <li><a href="index.php#services">Services</a></li>
            <li><a href="index.php#portfolio">Portfolio</a></li>
            <li><a href="index.php#careers">Join us</a></li>
            <!-- <li><a href="index.php#recent-posts">Blog</a></li> -->
            <li><a href="index.php#contact">Contact</a></li>
          </ul>

          <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav><!-- End Nav Menu -->
        <!-- <a href="index.php" class="logo-2 me-xl-0">
          <p> WE ARE ISO 9001 2015 Certified</p>
          
          <img src="assets/img/clients/ISO-1.jpg" alt="QPLUS" class="iso-1">
          <img src="assets/img/clients/ISO-2.png" alt="QPLUS" class="iso-2">
        </a> -->

        <a class="btn-getstarted" href="index.php#contact">Contact us</a>
      </div>


    </header><!-- End Header -->


    <main id="main">

      <!-- Services Details Page Title & Breadcrumbs -->
      <div data-aos="fade" class="page-title">
        <div class="heading">
          <div class="container">
            <div class="row d-flex justify-content-center text-center">
              <div class="col-lg-8">
                <h1>Services Details</h1>
                <p class="mb-0">Our services</p>
              </div>
            </div>
          </div>
        </div>
        <nav class="breadcrumbs">
          <div class="container">
            <ol>
              <li><a href="index.php">Home</a></li>
              <li class="current">Services Details</li>
            </ol>
          </div>
        </nav>
      </div><!-- End Page Title -->

      <!-- Service-details Section - Services Details Page -->
      <section id="about" class="about background-image">
        <div class="container" data-aos="fade-up">

          <div class="row position-relative">

            <div class="col-lg-7 about-img" style="background-image: url('assets/img/aboutus.jpeg');">

            </div>

            <div class="col-lg-7">
              <!-- <h2>Consequatur eius et magnam</h2> -->
              <div class="our-story">
                <!-- <h4>Est 1988</h4> -->
                <h3>About Us</h3>
                <p> Q Plus Technical Service LLC is a company raised by a team of
                  experienced professionals to provide a single window solution
                  for all Building Services, Interior Decoration, Electrical, HVAC,
                  Plumbing, IT & ELV requirements. Q Plus means, Quality plus
                  and we believe quality will be always a plus which will lead a
                  hassle free solutions. We study your requirements and
                  understand your needs, we design, propose and construct as per
                  requirements. We get to know your business in depth to provide
                  a solution which meets your goals. We ensure prompt responds
                  to your queries and attend to resolve your issues as a leader.
                  Along with bringing the best brands on the table, we undertake
                  all the incidental and ancillary services including installation,
                  maintenance, up gradation and repairs, thus giving our clients
                  complete peace of mind and hassle free business experience.
                  We continued to progress and earn respect of our clients as
                  being one of the honest, transparent and trustworthy service
                  providers across the UAE





                  <br>
                  <br>
                  <span class="fw-bold">We are ISO 9001:2015 Certified Company.</span>
                  <br>
                  <img src="assets/img/ISO 9001 2015.jpg" alt="responsive webite" height="100px" />
                  <img src="assets/img/ASCB.png" alt="responsive webite" height="100px" />
                </p>

              </div>
            </div>
          </div>

        </div>

        </div>
      </section>
      <!-- End About Section -->



      <!-- ======= Alt Services Section ======= -->
      <section id="alt-services" class="alt-services background-image">
        <div class="container" data-aos="fade-up">

          <div class="row justify-content-around gy-4">
            <div class="col-lg-6 img-bg" style="background-image: url( 'assets/img/vision.jpeg');" data-aos="zoom-in"
              data-aos-delay="120"></div>

            <div class="col-lg-5 d-flex flex-column justify-content-center">
              <h3>Our Vision</h3>
              <p>Our Vision is to provide a quality work from start to end
                by adopting modern construction technologies which
                will remind the Q Plus as a leader in the Market.
                Fortunately, we have a team of professionals having
                expertise in all the services and provides you with
                optimal solutions.</p>

            </div>
          </div>

        </div>
      </section><!-- End Alt Services Section -->

      <!-- ======= Alt Services Section 2 ======= -->
      <section id="alt-services-2" class="alt-services section-bg background-image">
        <div class="container" data-aos="fade-up">

          <div class="row justify-content-around gy-4">
            <div class="col-lg-5 d-flex flex-column justify-content-center">
              <h3>Our Mission</h3>
              <p>Our mission is to enhance business
                growth of our customers with high
                quality technologies and services that
                create valuable and reliable outcomes
              </p>


            </div>

            <div class="col-lg-6 img-bg" style="background-image: url('assets/img/mission.jpeg');" data-aos="zoom-in"
              data-aos-delay="120"></div>
          </div>

        </div>
      </section><!-- End Alt Services Section 2 -->






      <!-- <section id="service-details" class="service-details">

      <div class="container">

        <div class="row gy-5">

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">

            <div class="service-box">
              <h4>Serices List</h4>
              <div class="services-list">
                <a href="#" class="active"><i class="bi bi-arrow-right-circle"></i><span>Web Design</span></a>
                <a href="#"><i class="bi bi-arrow-right-circle"></i><span>Web Design</span></a>
                <a href="#"><i class="bi bi-arrow-right-circle"></i><span>Product Management</span></a>
                <a href="#"><i class="bi bi-arrow-right-circle"></i><span>Graphic Design</span></a>
                <a href="#"><i class="bi bi-arrow-right-circle"></i><span>Marketing</span></a>
              </div>
            </div>End Services List -->

      <!-- <div class="service-box">
              <h4>Download Catalog</h4>
              <div class="download-catalog">
                <a href="#"><i class="bi bi-filetype-pdf"></i><span>Catalog PDF</span></a>
                <a href="#"><i class="bi bi-file-earmark-word"></i><span>Catalog DOC</span></a>
              </div>
            </div>End Services List -->

      <!-- <div class="help-box d-flex flex-column justify-content-center align-items-center">
              <i class="bi bi-headset help-icon"></i>
              <h4>Have a Question?</h4>
              <p class="d-flex align-items-center mt-2 mb-0"><i class="bi bi-telephone me-2"></i> <span>+1 5589 55488 55</span></p>
              <p class="d-flex align-items-center mt-1 mb-0"><i class="bi bi-envelope me-2"></i> <a href="mailto:contact@example.com">contact@example.com</a></span></p>
            </div>

          </div>

          <div class="col-lg-8 ps-lg-5" data-aos="fade-up" data-aos-delay="200">
            <img src="assets/img/services.jpg" alt="" class="img-fluid services-img">
            <h3>Temporibus et in vero dicta aut eius lidero plastis trand lined voluptas dolorem ut voluptas</h3>
            <p>
              Blanditiis voluptate odit ex error ea sed officiis deserunt. Cupiditate non consequatur et doloremque consequuntur. Accusantium labore reprehenderit error temporibus saepe perferendis fuga doloribus vero. Qui omnis quo sit. Dolorem architecto eum et quos deleniti officia qui.
            </p>
            <ul>
              <li><i class="bi bi-check-circle"></i> <span>Aut eum totam accusantium voluptatem.</span></li>
              <li><i class="bi bi-check-circle"></i> <span>Assumenda et porro nisi nihil nesciunt voluptatibus.</span></li>
              <li><i class="bi bi-check-circle"></i> <span>Ullamco laboris nisi ut aliquip ex ea</span></li>
            </ul>
            <p>
              Est reprehenderit voluptatem necessitatibus asperiores neque sed ea illo. Deleniti quam sequi optio iste veniam repellat odit. Aut pariatur itaque nesciunt fuga.
            </p>
            <p>
              Sunt rem odit accusantium omnis perspiciatis officia. Laboriosam aut consequuntur recusandae mollitia doloremque est architecto cupiditate ullam. Quia est ut occaecati fuga. Distinctio ex repellendus eveniet velit sint quia sapiente cumque. Et ipsa perferendis ut nihil. Laboriosam vel voluptates tenetur nostrum. Eaque iusto cupiditate et totam et quia dolorum in. Sunt molestiae ipsum at consequatur vero. Architecto ut pariatur autem ad non cumque nesciunt qui maxime. Sunt eum quia impedit dolore alias explicabo ea.
            </p>
          </div>

        </div>

      </div>

    </section>End Service-details Section -->

    </main>

    <!-- =======Default  Footer ======= -->
    <footer id="footer" class="footer">

      <div class="container footer-top">
        <div class="row gy-4">
          <div class="col-lg-5 col-md-12 footer-about">
            <a class="logo d-flex align-items-center">
              <span style="color: white;font-size: large;margin-top: 10px">Our Social Networks<span>
            </a>

            <div class="social-links d-flex mt-4">
              <a href="https://twitter.com/qplus_q"><i class="bi bi-twitter"></i></a>
              <a href="https://www.facebook.com/Qplusts"><i class="bi bi-facebook"></i></a>
              <a href="https://www.instagram.com/qplustechnicalservice/"><i class="bi bi-instagram"></i></a>
              <a href="https://www.linkedin.com/company/qplus-technical-service-llc/"><i class="bi bi-linkedin"></i></a>
              <a href="https://wa.me/+971581174967"><i class="bi bi-whatsapp"></i></a>
              <a href="https://www.youtube.com/@Qplus201"><i class="bi bi-youtube"></i></a>
            </div>
          </div>

          <div class="col-lg-2 col-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><a href="index.php#home">Home</a></li>
              <li><a href="index.php#about">About us</a></li>
              <li><a href="index.php#services">Services</a></li>
              <li><a href="index.php#portfolio">Portfolio</a></li>
              <li><a href="index.php#careers">Join us</a></li>
              <li><a href="index.php#contact">Contact</a></li>
            </ul>
          </div>

          <div class="col-lg-2 col-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><a href="service-details.php">ELV services</a></li>
              <li><a href="service-details.php">IT and Networking Services</a></li>
              <li><a href="service-details.php">MEP Services</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-12 footer-contact text-center text-md-start">
            <h4>Contact Us</h4>
            <a href="https://goo.gl/maps/baR7adV2LxGMmDGF8">
              <p>Q Plus Technical Service LLC</p>
              <p>Office:702-20, Mai Tower, Al Nahda-1,</p>
              <p>Al Qusais, Dubai United Arab Emirates</p>
            </a>
            <p class="mt-4"><strong>Phone:</strong> <span>
             <p>Mob:<a href="tel:+971581174967"> +971 581174967</a></p>
             <p><a href="tel:+971585388100" style="margin-left: 39px;">+971 585388100</a></p>
             <p>Tel:</strong>&nbsp;&nbsp;&nbsp;<a href="tel:043931110"> +971 4 393 1110</a>
            </span></p>
            <p><strong><br>Email:</strong> <span><a href="mailto:info@qplus-ts.com">info@qplus-ts.com</span></a></p>
          </div>

        </div>
      </div>

      <div class="container copyright text-center mt-4">
        <p>&copy; <span>Copyright</span><strong class="px-1">DaCentric Technologies</b></strong><span>All Rights
            Reserved</span></p>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you've purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: [buy-url] -->
          <a href=""></a>
        </div>
      </div>

    </footer><!-- End Footer -->
    <!-- Scroll Top Button -->
    <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i
        class="bi bi-arrow-up-short"></i></a>

    <!-- Preloader -->
    <!-- <div id="preloader">
    <div></div>
    <div></div>
    <div></div>
    <div></div>
  </div> -->

    <!-- Vendor JS Files -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/aos/aos.js"></script>


    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>

  </body>

</html>